package com.capgemini.salesmanagement.exception;

public class InvalidProductPriceExcxeption extends Exception {

	public InvalidProductPriceExcxeption() {
		super();
	}

	public InvalidProductPriceExcxeption(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public InvalidProductPriceExcxeption(String message, Throwable cause) {
		super(message, cause);
	}

	public InvalidProductPriceExcxeption(String message) {
		super(message);
	}

	public InvalidProductPriceExcxeption(Throwable cause) {
		super(cause);
	}

}
