package com.capgemini.salesmanagement.client;

import java.util.HashMap;
import java.util.Scanner;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.excepion.ProductNameNotFoundException;
import com.capgemini.salesmanagement.exception.InvalidProductCode;
import com.capgemini.salesmanagement.exception.InvalidProductPriceExcxeption;
import com.capgemini.salesmanagement.exception.InvalidQuantity;
import com.capgemini.salesmanagement.exception.ProductNotFoundException;
import com.capgemini.salesmanagement.service.ISaleService;
import com.capgemini.salesmanagement.service.SaleService;
import com.capgemini.salesmanagement.util.CollectionUtil;

public class MainClass {

	public static void main(String[] args) {
		ISaleService services=new SaleService();
		Scanner sc=new Scanner(System.in);
		int prodCode = 0;
		int qty = 0;
		String prodCat = null;
		String prodName = null;
		float prodPrice;
		float LineTotal = 0;
		while(true) {
		try {
			System.out.println("Enter product code : ");
			prodCode = sc.nextInt();
			if(services.validateProductCode(prodCode));
			System.out.println("enter product quantity");
			qty = sc.nextInt();
			if(services.validateQuantity(qty));
			System.out.println("Enter the product category:===>1.Electronics   2.Toys  ");
			int ch=sc.nextInt();
			switch(ch) {
			case 1:
				prodCat="Electronics";System.out.println("Enter the product name===>1.TV  2.SmartPhone  3.VideoGame");
				int ch0ice=sc.nextInt();
				switch (ch0ice) {
				case 1:
					prodName="TV";
					break;
				case 2:
					prodName="SmartPhone";
					break;
				case 3:
					prodName="VideoGame";
					break;
					default:
						System.out.println("Product not avaliable");
				}
				break;
			case 2: 
				prodCat="Toys";System.out.println("Enter the product name===>1.Soft Toy  2.Telescope 3.BarbeeDoll");
				int ch0ice1=sc.nextInt();
				switch (ch0ice1) {
				case 1:
					prodName="SoftToy";
					break;
				case 2:
					prodName="Telescope";
					break;
				case 3:
					prodName="BarbeeDoll";
					break;
				default:
					System.out.println("Product not avaliable");
				}
				break;
			default:
				System.out.println("wrong Category");
			}
			if(services.validateProductCat(prodCat));
			
			if (services.vaildateProductName(prodName));
			System.out.println("Enter the product price ");
			prodPrice=sc.nextFloat();
			if(services.validateProductPrice(prodPrice));
			System.out.println("Enter the Line Total ");
			LineTotal=prodPrice*qty;
		}
		catch(InvalidProductCode e) {
			System.out.println("Invalid Product Code");
		} catch (InvalidQuantity e) {		
			System.out.println("Invalid Quantity");
		} catch (ProductNotFoundException e) {
			System.out.println("Invalid Category");
		} catch (ProductNameNotFoundException e) {
			System.out.println("Invalid Name");
		} catch (InvalidProductPriceExcxeption e) {
			System.out.println("Invlid Price Input");
		}
		Sale sale=new Sale(prodCode, prodCat,prodName, CollectionUtil.currDate(), qty, LineTotal);
		System.out.println("Sale Details:"+services.insertSalesDetails(sale));
		System.exit(0);
			}
		}
	}

