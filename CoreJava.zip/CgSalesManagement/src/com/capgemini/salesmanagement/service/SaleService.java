package com.capgemini.salesmanagement.service;

import java.util.HashMap;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.dao.ISaleDAO;
import com.capgemini.salesmanagement.dao.SaleDAO;
import com.capgemini.salesmanagement.excepion.ProductNameNotFoundException;
import com.capgemini.salesmanagement.exception.InvalidProductCode;
import com.capgemini.salesmanagement.exception.InvalidProductPriceExcxeption;
import com.capgemini.salesmanagement.exception.InvalidQuantity;
import com.capgemini.salesmanagement.exception.ProductNotFoundException;

public class SaleService implements ISaleService{
	private ISaleDAO sales=new SaleDAO();
	@Override
	public HashMap<Integer, Sale> insertSalesDetails(Sale sale) {
	
		return sales.insertSaleDetails(sale);
		}
	@Override
	public boolean validateProductCode(int productid) throws InvalidProductCode {
		if(productid==1001 || productid==1002 || productid==1003 || productid==1004)
			return true;
		else throw new InvalidProductCode();
	}
	@Override
	public boolean validateQuantity(int qty) throws InvalidQuantity {
		if(qty>0 && qty<5)
			return true;
		else
			throw new InvalidQuantity();
	}
	@Override
	public boolean validateProductCat(String prodCat) throws ProductNotFoundException {
		if (prodCat.equalsIgnoreCase("Electronics") || prodCat.equalsIgnoreCase("Toys"))
			return true;
		else
	throw new ProductNotFoundException();
	}
	@Override
	public boolean vaildateProductName(String prodName) throws ProductNameNotFoundException {
		if (prodName.equalsIgnoreCase("TV") || prodName.equalsIgnoreCase("SmartPhone") || prodName.equalsIgnoreCase("Videogame") ||prodName.equalsIgnoreCase("SoftToy") || prodName.equalsIgnoreCase("Telescope")|| prodName.equalsIgnoreCase("BarbeeDoll"))
			return true;
			throw new ProductNameNotFoundException();
	}
	@Override
	public boolean validateProductPrice(float price) throws InvalidProductPriceExcxeption {
		if(price>=200)
		return true;
		throw new InvalidProductPriceExcxeption();
	}

}
