package com.capgemini.takhome.test;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.takehome.beans.Product;
import com.capgemini.takehome.exception.InvalidCodeException;
import com.capgemini.takehome.exception.InvalidProductQuantity;
import com.capgemini.takehome.exception.ProductDetailsNotFoundException;
import com.capgemini.takehome.service.ProductService;
import com.capgemini.takehome.util.CollectionUtil;

public class TestClass {
	public static ProductService services;
	@BeforeClass
	public static void SetUpTestEnv() {
		services=new ProductService();
	}
	@Before
	public void  SetUpTestData() {
		Product product=new Product();
		CollectionUtil.products.put(product.getProductCode(), product);
		CollectionUtil.PRODUCT_CODE_COUNTER=1001;
	}
	@Test(expected=ProductDetailsNotFoundException.class)
	public void TestGetProductDetailsForInvalidProductCode()throws ProductDetailsNotFoundException{
		Product actualproduct=services.getProductDetails(1007);
	}
	@Test
	public void TestGetProductDetailsForValidProductCode()throws ProductDetailsNotFoundException{
		Product expectedproduct=new Product(1001, "iPhone", "Electronics", 35000);
		Product actualproduct=services.getProductDetails(1001);
		Assert.assertEquals(expectedproduct, actualproduct);
	}
	@Test
	public void TestProductForValidQuantity()throws InvalidProductQuantity{
		boolean returnedOutput=services.validateProductQuantity(23);
		boolean expectedOutput=true;
		Assert.assertEquals(expectedOutput, returnedOutput);
	}
	@Test(expected=InvalidProductQuantity.class)
	public void TestProductForInvalidQuantity()throws InvalidProductQuantity{
		boolean returnedOutput=services.validateProductQuantity(-23);
	}
	@Test
	public void TestForValidValidateProductCode()throws  InvalidCodeException{
		boolean returnedOutput=services.validateProductCode(1001);
		boolean expectedOutput=true;
		Assert.assertEquals(expectedOutput, returnedOutput);
	}
	@Test(expected=InvalidCodeException.class)
	public void TestForInvalidValidateProductCode()throws  InvalidCodeException{
		boolean returnedOutput=services.validateProductCode(10010);
	}

	@AfterClass
	public static void TearDownTestEnv() {
		services=null;
	}
}

