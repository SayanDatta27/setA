package com.capgemini.takehome.service;

import java.util.HashMap;
import java.util.List;

import com.capgemini.takehome.beans.Product;
import com.capgemini.takehome.dao.IProductDAO;
import com.capgemini.takehome.dao.ProductDAO;
import com.capgemini.takehome.exception.InvalidCodeException;
import com.capgemini.takehome.exception.InvalidProductQuantity;
import com.capgemini.takehome.exception.ProductDetailsNotFoundException;

public class ProductService implements IProductService{
	private IProductDAO iproductDao=new ProductDAO();
	private int productCode;
	Product product=new Product();
	
	@Override
	public Product getProductDetails(int productCode) throws ProductDetailsNotFoundException {
		Product product = iproductDao.getProductDetails(productCode);
		if(product==null)throw new ProductDetailsNotFoundException("Sorry!The Product Code"+productCode+"is not avaliable");
		return product;
	}
	@Override
	public boolean validateProductQuantity(int qty) throws InvalidProductQuantity {
		if(qty<=0)
		throw new InvalidProductQuantity();
		else
			return true;
	}
	@Override
	public boolean validateProductCode(int productCode) throws InvalidCodeException {
		if(String.valueOf(productCode).length()!=4)
			throw new InvalidCodeException();
		else
		return true;
	}
	@Override
	public float calculateLineTotal(float price, int qty) {
		System.out.println(product.getQuantity());
		float calculateLineTotal = product.getProductPrice()*product.getQuantity();
		return calculateLineTotal;
	}	
	}
	
	

