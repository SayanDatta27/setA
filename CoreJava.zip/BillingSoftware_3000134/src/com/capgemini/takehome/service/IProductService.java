package com.capgemini.takehome.service;

import java.util.HashMap;
import java.util.List;

import com.capgemini.takehome.beans.Product;
import com.capgemini.takehome.exception.InvalidCodeException;
import com.capgemini.takehome.exception.InvalidProductQuantity;
import com.capgemini.takehome.exception.ProductDetailsNotFoundException;
import com.capgemini.takehome.util.CollectionUtil;

public interface IProductService {
	Product getProductDetails(int productCode)throws ProductDetailsNotFoundException;
	boolean validateProductQuantity(int qty) throws InvalidProductQuantity;
	boolean validateProductCode(int productCode) throws InvalidCodeException;
	float calculateLineTotal(float price,int qty);
}
