package com.capgemini.takehome.client;

import java.util.Scanner;

import com.capgemini.takehome.beans.Product;
import com.capgemini.takehome.exception.InvalidCodeException;
import com.capgemini.takehome.exception.InvalidProductQuantity;
import com.capgemini.takehome.exception.ProductDetailsNotFoundException;
import com.capgemini.takehome.service.IProductService;
import com.capgemini.takehome.service.ProductService;

public class MainClass {

	public static void main(String[] args) throws ProductDetailsNotFoundException {
		IProductService service=new ProductService();
		System.out.println("1) Generate Bill by entering Product code as follows");
		System.out.println("2) Exit");
		Scanner sc=new Scanner(System.in);
		int choice=sc.nextInt();
		int qty=0;int productcode=0;
		switch(choice) {
		case 1:
			
			try {
			System.out.println("Enter the Product Code: ");
			 productcode=sc.nextInt();
				  if(service.validateProductCode(productcode));
				  System.out.println("Enter the quantity"); 
				   qty=sc.nextInt();
				   if(service.validateProductQuantity(qty));
				  Product product = service.getProductDetails(productcode);
				  product.setQuantity(qty);
				  product.setLineTotal(qty * product.getProductPrice());
				  System.out.println(product);
				  System.out.println(product.getLineTotal());
			}catch (InvalidCodeException e) {
				System.out.println("Sorry! The Product Code<<"+productcode+">>is not avalible");
			} catch (InvalidProductQuantity e) {	
				System.out.println("Product Code can not be 0");
			}
			
		break;
		case 2:
			System.exit(-1);
			}
		}
	}

