package com.capgemini.takehome.exception;

public class InvalidProductQuantity extends Exception {

	public InvalidProductQuantity() {
		super();
		
	}

	public InvalidProductQuantity(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	
	}

	public InvalidProductQuantity(String message, Throwable cause) {
		super(message, cause);
	
	}

	public InvalidProductQuantity(String message) {
		super(message);
		
	}

	public InvalidProductQuantity(Throwable cause) {
		super(cause);
		
	}

}
