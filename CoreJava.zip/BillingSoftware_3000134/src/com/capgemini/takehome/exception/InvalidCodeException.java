package com.capgemini.takehome.exception;

public class InvalidCodeException extends Exception {

	public InvalidCodeException() {
		super();	
	}

	public InvalidCodeException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public InvalidCodeException(String message, Throwable cause) {
		super(message, cause);
	}

	public InvalidCodeException(String message) {
		super(message);
	}

	public InvalidCodeException(Throwable cause) {
		super(cause);
	}

}
