package com.capgemini.takehome.dao;

import java.util.HashMap;
import java.util.List;

import com.capgemini.takehome.beans.Product;
import com.capgemini.takehome.exception.ProductDetailsNotFoundException;

public interface IProductDAO {
	Product getProductDetails(int productCode) throws ProductDetailsNotFoundException;
	
}
