package com.capgemini.takehome.dao;
import java.util.HashMap;

import com.capgemini.takehome.beans.Product;
import com.capgemini.takehome.exception.ProductDetailsNotFoundException;
import com.capgemini.takehome.util.CollectionUtil;

public class ProductDAO implements IProductDAO {
	@Override
	public Product getProductDetails(int productCode) throws ProductDetailsNotFoundException {
		Product product = CollectionUtil.products.get(productCode);
		if(product==null)
			throw new ProductDetailsNotFoundException("Product not found");
		return product;
	}
}