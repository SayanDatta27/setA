package com.capgemini.takehome.beans;

public class Product {
	private int productId;
	private String productName,ptoductCategory;
	private float productPrice;
	private int productCode;
	private float LineTotal;
	private int quantity;	
	public Product() {
		super();
	}
	public Product(String productName, String ptoductCategory, float productPrice) {
		super();
		this.productName = productName;
		this.ptoductCategory = ptoductCategory;
		this.productPrice = productPrice;
	}	
	public Product(int productId, String productName, String ptoductCategory, float productPrice, int productCode,
			float lineTotal, int quantity) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.ptoductCategory = ptoductCategory;
		this.productPrice = productPrice;
		this.productCode = productCode;
		LineTotal = lineTotal;
		this.quantity = quantity;
	}
	public Product(int productId, int quantity) {
		super();
		this.productId = productId;
		this.quantity = quantity;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Float.floatToIntBits(LineTotal);
		result = prime * result + productCode;
		result = prime * result + productId;
		result = prime * result + ((productName == null) ? 0 : productName.hashCode());
		result = prime * result + Float.floatToIntBits(productPrice);
		result = prime * result + ((ptoductCategory == null) ? 0 : ptoductCategory.hashCode());
		result = prime * result + quantity;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Product other = (Product) obj;
		if (Float.floatToIntBits(LineTotal) != Float.floatToIntBits(other.LineTotal))
			return false;
		if (productCode != other.productCode)
			return false;
		if (productId != other.productId)
			return false;
		if (productName == null) {
			if (other.productName != null)
				return false;
		} else if (!productName.equals(other.productName))
			return false;
		if (Float.floatToIntBits(productPrice) != Float.floatToIntBits(other.productPrice))
			return false;
		if (ptoductCategory == null) {
			if (other.ptoductCategory != null)
				return false;
		} else if (!ptoductCategory.equals(other.ptoductCategory))
			return false;
		if (quantity != other.quantity)
			return false;
		return true;
	}
	public Product(int productId, String productName, String ptoductCategory, float productPrice) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.ptoductCategory = ptoductCategory;
		this.productPrice = productPrice;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getPtoductCategory() {
		return ptoductCategory;
	}
	public void setPtoductCategory(String ptoductCategory) {
		this.ptoductCategory = ptoductCategory;
	}
	public float getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(float productPrice) {
		this.productPrice = productPrice;
	}
	
	public int getProductCode() {
		return productCode;
	}
	public void setProductCode(int productCode) {
		this.productCode = productCode;
	}
	
	public float getLineTotal() {
		return LineTotal;
	}
	public void setLineTotal(float lineTotal) {
		LineTotal = lineTotal;
	}
	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return  productCode + ",\nproductId=" + productId + ", \nproductName=" + productName + ", \nptoductCategory="
				+ ptoductCategory + ", \nproductPrice=" + productPrice + ", \n quantity=" + quantity+",\n Line Total="+LineTotal+")" ;
	}
}
